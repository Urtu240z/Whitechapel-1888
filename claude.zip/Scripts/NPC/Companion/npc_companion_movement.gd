extends Node

# ============================================================================
# COMPANION MOVEMENT MODULE
# Gestiona movimiento de la companion: gravedad, facing, velocidad.
# El control de modo (wander/follow/idle) lo gestiona npc_companion.gd.
# ============================================================================

var companion: CharacterBody2D = null

var facing_right: bool = true
var _was_moving: bool = false

@export var walk_speed: float = 120.0
@export var gravity: float = 980.0

# ============================================================================
# INIT
# ============================================================================
func initialize(c: CharacterBody2D) -> void:
	companion = c

# ============================================================================
# GETTERS
# ============================================================================
func is_moving() -> bool:
	return _was_moving

func get_facing_direction() -> bool:
	return facing_right

func is_frozen() -> bool:
	return companion.velocity.x == 0.0 and _was_moving == false

# ============================================================================
# PROCESS — llamado desde npc_companion._physics_process
# ============================================================================
func apply_gravity(delta: float) -> void:
	if not companion.is_on_floor():
		companion.velocity.y += gravity * delta
	else:
		companion.velocity.y = 0.0

func update_movement_state() -> void:
	var speed: float = abs(companion.velocity.x)
	if speed > 10.0:
		_was_moving = true
	elif speed < 3.0:
		_was_moving = false

func set_facing(facing: bool) -> void:
	facing_right = facing
	var container := companion.get_node_or_null("CharacterContainer") as Node2D
	if not container:
		return
	var sx: float = abs(container.scale.x)
	container.scale.x = sx if facing_right else -sx
