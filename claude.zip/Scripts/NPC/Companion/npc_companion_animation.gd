extends Node

# ============================================================================
# COMPANION ANIMATION MODULE
# Gestiona animaciones de la companion: Idle, Walk.
# ============================================================================

var companion: CharacterBody2D = null
var movement: Node = null

var _anim_tree: AnimationTree = null
var _state_machine: AnimationNodeStateMachinePlayback = null
var _sprite_container: Node2D = null
var _last_state: String = ""

# ============================================================================
# INIT
# ============================================================================
func initialize(c: CharacterBody2D, facing_right: bool = true) -> void:
	companion = c

	_anim_tree = companion.get_node_or_null("AnimationTree")
	_sprite_container = companion.get_node_or_null("CharacterContainer")

	if companion.has_node("Movement"):
		movement = companion.get_node("Movement")

	if _anim_tree:
		_anim_tree.active = true
		_state_machine = _anim_tree["parameters/playback"]
		_go_to("Idle")

	_apply_facing(facing_right)

# ============================================================================
# UPDATE — llamado desde npc_companion._physics_process
# ============================================================================
func update(delta: float) -> void:
	if not _state_machine:
		return
	_update_state()
	_update_facing()

func _update_state() -> void:
	var is_moving: bool = abs(companion.velocity.x) > 10.0
	var desired: String = "Walk" if is_moving else "Idle"
	if desired != _last_state:
		_go_to(desired)

func _update_facing() -> void:
	if not _sprite_container:
		return
	var vx: float = companion.velocity.x
	if vx > 5.0:
		_apply_facing(true)
	elif vx < -5.0:
		_apply_facing(false)

# ============================================================================
# API
# ============================================================================
func force_idle() -> void:
	_go_to("Idle")

func set_walking(walking: bool) -> void:
	_go_to("Walk" if walking else "Idle")

# ============================================================================
# HELPERS
# ============================================================================
func _go_to(state: String) -> void:
	if _last_state == state:
		return
	if _state_machine:
		_state_machine.travel(state)
	_last_state = state

func _apply_facing(facing_right: bool) -> void:
	if not _sprite_container:
		return
	var sx: float = abs(_sprite_container.scale.x)
	_sprite_container.scale.x = sx if facing_right else -sx
