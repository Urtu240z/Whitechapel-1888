extends CharacterBody2D

# ============================================================================
# NPC COMPANION
# Companion NPC con wander por waypoints (ping-pong), modo follow y diálogo.
# ============================================================================

# ============================================================================
# CONFIG
# ============================================================================
@export_group("🧍 Companion")
@export var companion_name: String = "Mary"
@export_file("*.dtl") var dialog_timeline: String = ""
@export var initial_facing_right: bool = true

@export_group("🏃 Movement")
@export var walk_speed: float = 120.0
@export var follow_speed: float = 180.0
@export var follow_dist_min: float = 150.0
@export var follow_dist_max: float = 350.0
@export var gravity: float = 980.0

@export_group("📍 Waypoints")
@export var waypoints: Array[NodePath] = []
@export var wait_time_at_waypoint: float = 3.0

# ============================================================================
# REFERENCIAS
# ============================================================================
@onready var animation: Node = $Animation
@onready var audio: Node = $Audio
@onready var conversation: Node = $Conversation

# ============================================================================
# ESTADO
# ============================================================================
enum Mode { IDLE, WANDER, FOLLOW, DIALOG }

var _mode: Mode = Mode.IDLE
var _waypoint_nodes: Array = []
var _current_waypoint_idx: int = 0
var _waypoint_direction: int = 1
var _waiting: bool = false
var _wait_timer: float = 0.0
var _facing_right: bool = true

# ============================================================================
# READY
# ============================================================================
func _ready() -> void:
	add_to_group("npc_companion")

	for np in waypoints:
		var node = get_node_or_null(np)
		if node:
			_waypoint_nodes.append(node)
		else:
			push_warning("NPC_Companion '%s': waypoint no encontrado: %s" % [companion_name, np])

	if animation:
		animation.initialize(self, initial_facing_right)
	if audio:
		audio.initialize(self)
	if conversation:
		conversation.initialize(self)

	_facing_right = initial_facing_right
	_apply_facing(_facing_right)

	if _waypoint_nodes.size() > 0:
		set_mode(Mode.WANDER)
	else:
		set_mode(Mode.IDLE)

# ============================================================================
# LOOP
# ============================================================================
func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y += gravity * delta
	else:
		velocity.y = 0.0

	match _mode:
		Mode.WANDER:
			_process_wander(delta)
		Mode.FOLLOW:
			_process_follow(delta)
		Mode.IDLE, Mode.DIALOG:
			velocity.x = 0.0

	move_and_slide()

	if animation:
		animation.update(delta)

# ============================================================================
# WANDER — ping-pong por waypoints
# ============================================================================
func _process_wander(delta: float) -> void:
	if _waypoint_nodes.is_empty():
		velocity.x = 0.0
		return

	if _waiting:
		velocity.x = 0.0
		_wait_timer -= delta
		if _wait_timer <= 0.0:
			_waiting = false
			_advance_waypoint()
		return

	var target: Node2D = _waypoint_nodes[_current_waypoint_idx]
	if not is_instance_valid(target):
		velocity.x = 0.0
		return

	var diff: float = target.global_position.x - global_position.x
	var dist: float = abs(diff)

	if dist < 8.0:
		velocity.x = 0.0
		global_position.x = target.global_position.x
		_waiting = true
		_wait_timer = wait_time_at_waypoint
		return

	var dir: float = sign(diff)
	velocity.x = dir * walk_speed
	_set_facing(dir > 0.0)

# ============================================================================
# FOLLOW — sigue al player
# ============================================================================
func _process_follow(_delta: float) -> void:
	var player := _get_player()
	if not player:
		velocity.x = 0.0
		return

	var diff: float = player.global_position.x - global_position.x
	var dist: float = abs(diff)

	if dist <= follow_dist_min:
		velocity.x = 0.0
		return

	var dir: float = sign(diff)
	var speed: float = lerp(walk_speed, follow_speed, clamp((dist - follow_dist_min) / follow_dist_max, 0.0, 1.0))
	velocity.x = dir * speed
	_set_facing(dir > 0.0)

# ============================================================================
# API PÚBLICA
# ============================================================================
func set_mode(new_mode: Mode) -> void:
	_mode = new_mode
	_waiting = false
	if new_mode == Mode.WANDER and _waypoint_nodes.is_empty():
		_mode = Mode.IDLE

func start_follow() -> void:
	set_mode(Mode.FOLLOW)

func stop_follow() -> void:
	set_mode(Mode.WANDER if _waypoint_nodes.size() > 0 else Mode.IDLE)

func start_dialog() -> void:
	if dialog_timeline.is_empty():
		push_warning("NPC_Companion '%s': no tiene dialog_timeline asignado." % companion_name)
		return
	if not get_tree().root.has_node("Dialogic"):
		return
	if not StateManager.can_enter(StateManager.State.DIALOG):
		return

	var prev_mode := _mode
	set_mode(Mode.DIALOG)

	var player := _get_player()
	if player:
		_set_facing(player.global_position.x > global_position.x)
		player.disable_movement()

	StateManager.enter(StateManager.State.DIALOG)
	Dialogic.start(dialog_timeline)
	Dialogic.timeline_ended.connect(func():
		StateManager.exit(StateManager.State.DIALOG)
		var p := _get_player()
		if p:
			p.enable_movement()
		set_mode(prev_mode)
	, CONNECT_ONE_SHOT)

func freeze() -> void:
	set_mode(Mode.IDLE)

func unfreeze() -> void:
	set_mode(Mode.WANDER if _waypoint_nodes.size() > 0 else Mode.IDLE)

func get_display_name() -> String:
	return companion_name

# ============================================================================
# WAYPOINTS
# ============================================================================
func _advance_waypoint() -> void:
	if _waypoint_nodes.size() <= 1:
		return

	_current_waypoint_idx += _waypoint_direction

	if _current_waypoint_idx >= _waypoint_nodes.size():
		_waypoint_direction = -1
		_current_waypoint_idx = _waypoint_nodes.size() - 2
	elif _current_waypoint_idx < 0:
		_waypoint_direction = 1
		_current_waypoint_idx = 1

# ============================================================================
# FACING
# ============================================================================
func _set_facing(facing_right: bool) -> void:
	if _facing_right == facing_right:
		return
	_facing_right = facing_right
	_apply_facing(facing_right)

func _apply_facing(facing_right: bool) -> void:
	var container := get_node_or_null("CharacterContainer") as Node2D
	if not container:
		return
	var sx: float = abs(container.scale.x)
	container.scale.x = sx if facing_right else -sx

# ============================================================================
# HELPERS
# ============================================================================
func _get_player() -> Node2D:
	if PlayerManager and PlayerManager.player_instance:
		return PlayerManager.player_instance as Node2D
	return get_tree().get_first_node_in_group("player") as Node2D
