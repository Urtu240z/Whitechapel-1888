extends Node

# ============================================================================
# COMPANION AUDIO MODULE
# Gestiona pasos de la companion según superficie.
# Sin tos, sin respiración — solo pasos.
# ============================================================================

var companion: CharacterBody2D = null

@onready var step_player: AudioStreamPlayer = $StepPlayer

const SURFACE_DEFAULT := "stone"
const VALID_SURFACES := ["stone", "wood", "dirt", "grass", "water"]

var current_surface: String = SURFACE_DEFAULT

@export var step_sounds: Dictionary = {
	"stone": [],
	"wood":  [],
	"dirt":  [],
	"grass": [],
	"water": [],
}

# ============================================================================
# INIT
# ============================================================================
func initialize(c: CharacterBody2D) -> void:
	companion = c
	var shadow_ray: RayCast2D = companion.get_node_or_null("CharacterContainer/Shadow/ShadowRAY")
	if shadow_ray:
		shadow_ray.add_exception(companion)

# ============================================================================
# PROCESS
# ============================================================================
func _process(_delta: float) -> void:
	_update_surface()

# ============================================================================
# SURFACE DETECTION
# ============================================================================
func _update_surface() -> void:
	var shadow_ray: RayCast2D = companion.get_node_or_null("CharacterContainer/Shadow/ShadowRAY")
	if not shadow_ray or not shadow_ray.is_colliding():
		return

	var collider = shadow_ray.get_collider()
	if not collider:
		return

	var detected := SURFACE_DEFAULT

	if collider is TileMapLayer or collider is TileMap:
		var tile_pos: Vector2i = collider.local_to_map(
			collider.to_local(shadow_ray.get_collision_point())
		)
		var tile_data: TileData = collider.get_cell_tile_data(0, tile_pos)
		if tile_data:
			var surface = tile_data.get_custom_data("surface_type")
			if surface != "":
				detected = surface
	elif collider.has_meta("surface_type"):
		detected = collider.get_meta("surface_type")

	if detected in VALID_SURFACES:
		current_surface = detected

# ============================================================================
# PASOS — llamado desde Call Method Track del AnimationPlayer
# ============================================================================
func play_step(run: bool = false) -> void:
	if not companion.is_on_floor():
		return

	var sounds: Array = step_sounds.get(current_surface, [])
	if sounds.is_empty():
		sounds = step_sounds.get(SURFACE_DEFAULT, [])
	if sounds.is_empty():
		return

	step_player.stream = sounds.pick_random()
	step_player.pitch_scale = randf_range(1.0, 1.3) if run else randf_range(0.9, 1.1)
	step_player.play()
